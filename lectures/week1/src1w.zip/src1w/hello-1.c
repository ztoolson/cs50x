/**
 * hello-1.c
 *
 * David J. Malan
 * malan@harvard.edu
 *
 * Says hello to just David.
 *
 * Demonstrates use of CS50's library.
 */
       
#include <cs50.h>
#include <stdio.h>

int main(void)
{
    string name = "David";
    printf("hello, %s\n", name);
}
