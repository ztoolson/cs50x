/**
 * ascii-1.c
 *
 * David J. Malan
 * malan@harvard.edu
 *
 * Displays the mapping between alphabetical ASCII characters and
 * their decimal equivalents.
 *
 * Demonstrates casting from char to int.
 */

#include <stdio.h>

int main(void)
{
    // display mapping for uppercase letters
    for (int c = 'A'; c <= 'Z'; c++)
    {
        printf("%c: %i\n", c, (int) c);
    }

    // separate uppercase from lowercase
    printf("\n");

    // display mapping for lowercase letters
    for (int c = 'a'; c <= 'z'; c++)
    {
        printf("%c: %i\n", i, (int) i);
    }
}
