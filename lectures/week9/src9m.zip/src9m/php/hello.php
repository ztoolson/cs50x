#!/bin/env php
<?php

    /**
     * hello
     *
     * David J. Malan
     * malan@harvard.edu
     *
     * Says hello to the world.
     *
     * Demonstrates use of a shebang with env.
     */

    printf("hello, world\n");

?>
