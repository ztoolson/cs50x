<?php

    /**
     * register-0.php
     *
     * David J. Malan
     * malan@harvard.edu
     *
     * Dumps contents of $_POST.
     */

?>

<!DOCTYPE html>

<html>
    <head>
        <title>Frosh IMs</title>
    </head>
    <body>
        <pre>
            <?php print_r($_POST); ?>
        </pre>
    </body>
</html>
