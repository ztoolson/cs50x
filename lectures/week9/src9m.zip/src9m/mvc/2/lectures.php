<?php require("helpers.php"); ?>

<?php renderHeader(["title" => "Lectures"]); ?>

<ul>
    <li><a href="week0.php">Week 0</a></li>
    <li><a href="week1.php">Week 1</a></li>
</ul>

<?php renderFooter(); ?>
