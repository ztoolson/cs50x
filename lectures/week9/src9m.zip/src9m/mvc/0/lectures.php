<?php 

    /**
     * lectures.php
     *
     * David J. Malan
     * malan@harvard.edu
     *
     * Links to lectures.
     */

?>

<!DOCTYPE html>

<html>
    <head>
        <title>Lectures</title>
    </head>
    <body>
        <h1>Lectures</h1>
        <ul>
            <li><a href="week0.php">Week 0</a></li>
            <li><a href="week1.php">Week 1</a></li>
        </ul>
    </body>
</html>
