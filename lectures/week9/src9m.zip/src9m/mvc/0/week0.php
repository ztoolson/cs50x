<?php 

    /**
     * week0.php
     *
     * David J. Malan
     * malan@harvard.edu
     *
     * Represents Week 0.
     */

?>

<!DOCTYPE html>

<html>
    <head>
        <title>Week 0</title>
    </head>
    <body>
        <h1>Week 0</h1>
        <ul>
            <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/w/week0w.pdf">Wednesday</a></li>
            <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/f/week0f.pdf">Friday</a></li>
        </ul>
    </body>
</html>
