<?php 

    /**
     * index.php
     *
     * David J. Malan
     * malan@harvard.edu
     *
     * A home page for the course.
     */

?>

<!DOCTYPE html>

<html>
    <head>
        <title>CS50</title>
    </head>
    <body>
        <h1>CS50</h1>
        <ul>
            <li><a href="lectures.php">Lectures</a></li>
            <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/w/syllabus/syllabus.html">Syllabus</a></li>
        </ul>
    </body>
</html>
