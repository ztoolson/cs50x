<?php require("header.php"); ?>

<ul>
  <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/w/week0w.pdf">Wednesday</a></li>
  <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/f/week0f.pdf">Friday</a></li>
</ul>

<?php require("footer.php"); ?>
