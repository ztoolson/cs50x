<?php require("header.php"); ?>

<ul>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/1/m/week1m.pdf">Monday</a></li>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/1/w/week1w.pdf">Wednesday</a></li>
</ul>

<?php require("footer.php"); ?>
