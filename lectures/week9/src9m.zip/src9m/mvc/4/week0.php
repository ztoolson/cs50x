<?php require("includes/helpers.php"); ?>

<?php render("header", ["title" => "Week 0"]); ?>

<ul>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/w/week0w.pdf">Wendesday</a></li>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/f/week0f.pdf">Friday</a></li>
</ul>

<?php render("footer"); ?>
