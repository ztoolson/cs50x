<?php require("includes/helpers.php"); ?>

<?php render("header", ["title" => "Week 1"]); ?>

<ul>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/1/week1m.pdf">Monday</a></li>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/1/week1w.pdf">Wednedsay</a></li>
</ul>

<?php render("footer"); ?>
