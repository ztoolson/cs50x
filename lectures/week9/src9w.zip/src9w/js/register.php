<!DOCTYPE html>

<html>
    <head>
        <title>register</title>
    </head>
    <body>
        You are registered!  (Well, not really.)
    </body>
</html>
