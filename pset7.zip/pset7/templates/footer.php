
            </div>
            <div id="bottom">
                <div>
                    <a href="logout.php">Log Out</a>
                </div>
                <div>
                    <a href="change_password.php">Change Password</a>
                </div>
                Copyright &#169; Zach Toolson
            </div>

        </div>

    </body>

</html>
