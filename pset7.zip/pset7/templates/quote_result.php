A share of <?= $q_name ?> (<?= $q_symbol ?>) costs $<?= $q_price ?>.
