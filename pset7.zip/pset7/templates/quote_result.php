A share of <?= $q_name ?> (<?= $q_symbol ?>) costs $<?= $q_price ?>.
<div>
    <br/>
    get another <a href="quote.php">quote</a>.
    <br/>
    return to <a href="/">portfolio</a>.
</div>
